package kz.hcsbk.pushnotify;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class FoneService extends Service {

    //private static String LOG ="FoneService",
            //url1="http://10.0.2.2/AgentsNetwork/Push/GetNewMessages",
            //url2="http://10.0.2.2/AgentsNetwork/Push/TokenValidation",
            //url3="http://10.0.2.2/AgentsNetwork/Push/GetNewMessagesReport",
           // url4="http://10.0.2.2/AgentsNetwork/Push/AcceptFromAgent";
    //private static String LOG ="FoneService",
            //url1="http://bpmd:8080/Push/GetNewMessages",
            //url2="http://bpmd:8080/Push/TokenValidation",
            //url3="http://bpmd:8080/Push/GetNewMessagesReport",
            //url4="http://bpmd:8080/Push/AcceptFromAgent";
    private static String LOG ="FoneService",
            url1="http://consultant-app.hcsbk.kz/Push/GetNewMessages",
            url2="http://consultant-app.hcsbk.kz/Push/TokenValidation",
            url3="http://consultant-app.hcsbk.kz/Push/GetNewMessagesReport",
            url4="http://consultant-app.hcsbk.kz/Push/AcceptFromAgent";
    private int INDEX = 6004;
    private PushMessageDBHelper dbHelper;
    private static HttpPost httpPost;
    private static DefaultHttpClient httpClient;
    private static UrlEncodedFormEntity urlEncodedFormEntity;
    private static HttpResponse httpResponse;
    private static ArrayList<NameValuePair> nameValuePairs;
    private static StringBuilder stringBuilder;
    private InputStream inputStream;
    private InputStreamReader inputStreamReader;
    private BufferedReader bufferedReader;
    private Timer myTimer;
    private static File file;

    @Override
    public void onCreate() {
        super.onCreate();
        //ShowNotify("Test","Test");
        try {
            dbHelper = new PushMessageDBHelper(getApplicationContext());
            httpPost = new HttpPost();
            myTimer = new Timer();
            httpClient = new DefaultHttpClient();
            file = new File(Environment.getExternalStorageDirectory(),"HCSBK-SSK/AppData/Push.tkn");
            Log.i(LOG, "=> onCreate");
        }
        catch (Exception ex){
            Log.i(LOG, ex.getMessage());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(LOG, "=> onBind");
        return null;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        Log.i(LOG, "=> onStart");
        startService();
    }

    private void startService() {

        myTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                if(file.exists())
                {
                    String token = GetToken();
                    Log.i(LOG, "GetToken => " + token);
                    String lastId = dbHelper.GetLastID();
                    Log.i(LOG, "LastID => " + lastId);
                    String flag = Validation(token);
                    Log.i(LOG, "Validation => " + flag);

                    if(flag==null)
                        Log.i(LOG, "=> Ошибка при получении токена!");
                    else if (flag!=null && flag.equals("True"))
                    {
                        nameValuePairs = new ArrayList<NameValuePair>(2);
                        stringBuilder = new StringBuilder();

                        try
                        {
                            httpPost = new HttpPost(url1);
                            nameValuePairs.add(new BasicNameValuePair("messageId", lastId));
                            nameValuePairs.add(new BasicNameValuePair("agentId", token));
                            urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairs);
                            httpPost.setEntity(urlEncodedFormEntity);
                            httpResponse = httpClient.execute(httpPost);
                            inputStream = httpResponse.getEntity().getContent();
                            inputStreamReader = new InputStreamReader(inputStream);
                            bufferedReader = new BufferedReader(inputStreamReader);

                            String bufferedStrChunk;
                            while ((bufferedStrChunk = bufferedReader.readLine()) != null)
                            {
                                stringBuilder.append(bufferedStrChunk);
                            }

                            String answer = stringBuilder.toString();

                            Log.i(LOG, "=> Ответ от сервера: " + answer + "");
                            //ShowNotify("Ответ сервера",answer);
                            if (answer != null && !answer.trim().equals(""))
                            {
                                try
                                {
                                    JSONObject jo = new JSONObject(answer);
                                    JSONArray ja = jo.getJSONArray("data");

                                    for(int i=0;i<ja.length();i++)
                                    {
                                        jo = ja.getJSONObject(i);

                                        Log.i(LOG, "=>" + jo.getInt("Id") + " | " + jo.getString("Title") + " | " + jo.getString("Content") + " | " + jo.getString("LinkCode") + " | " + jo.getString("LinkData") + " | " + jo.getString("CurrentDate"));

                                        Intent notificationIntent = new Intent(getApplicationContext(), MainActivity.class);
                                        PendingIntent mainActivityIntent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                                        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext())
                                                .setSmallIcon(R.mipmap.ic_launcher)
                                                .setVibrate(new long[]{1000, 1000})
                                                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                                                .setAutoCancel(true)
                                                .setContentIntent(mainActivityIntent)
                                                .setContentTitle(jo.getString("Title"))
                                                .setContentText(jo.getString("Content"));

                                        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                                        manager.notify(jo.getInt("Id"), builder.build());

                                        dbHelper.InsertMessage(jo.getInt("Id"), jo.getString("Title"), jo.getString("Content"), jo.getString("LinkCode"), jo.getString("LinkData"), jo.getString("CurrentDate"));

                                        PushReport(String.valueOf(jo.getInt("Id")), token);

                                        Log.i(LOG, "=> " + String.valueOf(jo.getInt("Id") + " сохранен в БД и доставлен н сервер!"));

                                        sendBroadcast(new Intent("kz.hcsbk.action.UPDATE_ListView"));
                                    }
                                }
                                catch (Exception e)
                                {
                                    Log.i(LOG, "=> Ошибка ответа от сервера:\n" + e.getMessage());
                                }
                            }
                            else
                            {
                                Log.i(LOG, "=> Ответ не содержит JSON!");
                            }
                        }
                        catch (Exception e)
                        {
                            Log.i(LOG, "=> Ошибка:\n" + e.getMessage());
                        }
                    }
                    else
                    {
                        Log.i(LOG, "=> Удаление файла токена!");
                        file.delete();
                    }
                }
                else
                    Log.i(LOG, "=> Файл токена не существует!");
            }
        }, 0, 15);
    }

    //Получение токена
    private String GetToken() {

        StringBuilder sb = new StringBuilder();

        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String cLine;

            while ((cLine = br.readLine()) != null) {
                sb.append(cLine);
            }
            br.close();

            String result = sb.toString().replace("\uFEFF", "");

            return result;
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    // Валидация агента
    private String Validation(String token) {
        nameValuePairs = new ArrayList<NameValuePair>(1);
        stringBuilder = new StringBuilder();
        if (token != "" && token != null){
            try {
                httpPost = new HttpPost(url2);
                nameValuePairs.add(new BasicNameValuePair("agentId", token));
                urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairs);
                httpPost.setEntity(urlEncodedFormEntity);
                httpResponse = httpClient.execute(httpPost);
                inputStream = httpResponse.getEntity().getContent();
                inputStreamReader = new InputStreamReader(inputStream);
                bufferedReader = new BufferedReader(inputStreamReader);
                String bufferedStrChunk;
                while ((bufferedStrChunk = bufferedReader.readLine()) != null) {
                    stringBuilder.append(bufferedStrChunk);
                }
                String answer = stringBuilder.toString();
                return answer;
            }
            catch (Exception e) {
                Log.i(LOG, "Validation => Ошибка:\n" + e.getMessage());
            }
        }
        return null;
    }

    // Отчет о доставке пуша.
    private void PushReport(String messageId,String agentId) {
        nameValuePairs = new ArrayList<NameValuePair>(2);
        try
        {
            httpPost = new HttpPost(url3);
            nameValuePairs.add(new BasicNameValuePair("messageId",messageId));
            nameValuePairs.add(new BasicNameValuePair("agentId",agentId));
            urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairs);
            httpPost.setEntity(urlEncodedFormEntity);
            httpClient.execute(httpPost);
            Log.i(LOG, "PushReport => Отчет успешно отправлен на сервер!");
        }
        catch (Exception e)
        {
            Log.i(LOG, "PushReport => Ошибка:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    // Отчет о доставке пуша от агента.
    public class AcceptFromAgent extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... post)
        {
            nameValuePairs = new ArrayList<NameValuePair>(2);
            String tks = GetToken();
            String valid = Validation(tks);

            if(valid==null)
                Log.i(LOG, "=> Ошибка при получении токена!");
            else if (valid!=null && valid.equals("True")) {
                try {
                    String messageId = post[0];
                    httpPost = new HttpPost(url4);
                    nameValuePairs.add(new BasicNameValuePair("messageId", messageId));
                    nameValuePairs.add(new BasicNameValuePair("agentId", tks));
                    urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairs);
                    httpPost.setEntity(urlEncodedFormEntity);
                    httpClient.execute(httpPost);
                    Log.i(LOG, "AcceptFromAgent => Отчет успешно отправлен на сервер!");
                }
                catch (Exception e) {
                    Log.i(LOG, "AcceptFromAgent => Ошибка:\n" + e.getMessage());
                }
            }
            else
            {
                Log.i(LOG, "=> Удаление файла токена!");
                file.delete();
            }
            return null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(LOG, "=> onDestroy");
    }

    public void ShowNotify(String title, String message)
    {
        Intent notificationIntent = new Intent(getApplicationContext(), MainActivity.class);
        PendingIntent mainActivityIntent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setVibrate(new long[]{1000, 1000})
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setAutoCancel(true)
                .setContentIntent(mainActivityIntent)
                .setContentTitle(title)
                .setContentText(message);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(this.INDEX, builder.build());
    }
}
