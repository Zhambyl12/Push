package kz.hcsbk.pushnotify;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;

public class PushMessageDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Push";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "PushMessage";
    private static final String ID = "Id";
    private static final String TITLE = "Title";
    private static final String CONTENT = "Content";
    private static final String LINKCODE = "LinkCode";
    private static final String LINKDATA = "LinkData";
    private static final String CURRENTDATE = "CurrentDate";
    private static final String STATE = "State";

    public PushMessageDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(" CREATE TABLE " + TABLE_NAME + " (" +
                ID + " INTEGER PRIMARY KEY," +
                TITLE + " TEXT, " +
                CONTENT + " TEXT, " +
                LINKCODE + " TEXT, " +
                LINKDATA + " TEXT, " +
                CURRENTDATE + " TEXT, " +
                STATE + " INTEGER);"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }

    public boolean InsertMessage (int id, String title, String content, String linkCode, String linkData,String currentDate) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, id);
        contentValues.put(TITLE, title);
        contentValues.put(CONTENT, content);
        contentValues.put(LINKCODE, linkCode);
        contentValues.put(LINKDATA, linkData);
        contentValues.put(CURRENTDATE, currentDate);
        contentValues.put(STATE, 0);
        db.insert(TABLE_NAME, null, contentValues);
        return true;
    }

    public boolean UpdateMessage (String id) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(STATE, 1);
        db.update(TABLE_NAME, contentValues, ""+ID+" = ? ", new String[] { id } );
        return true;
    }

    public String GetLastID() {

        SQLiteDatabase db = this.getReadableDatabase();
        int last_id=0;
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME, null);
        if (cursor.moveToLast()) {
            last_id = cursor.getInt(0);
        }
        return String.valueOf(last_id);
    }

    public ArrayList<HashMap<String, String>> GetAllMessages() {

        ArrayList<HashMap<String, String>> array_list = new ArrayList<HashMap<String, String>>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT * FROM "+TABLE_NAME, null);
        res.moveToFirst();

        while(res.isAfterLast() == false){

            HashMap<String, String> hashmap = new HashMap<String, String>();
            hashmap.put(ID, res.getString(res.getColumnIndex(ID)));
            hashmap.put(TITLE, res.getString(res.getColumnIndex(TITLE)));
            hashmap.put(CONTENT, res.getString(res.getColumnIndex(CONTENT)));
            hashmap.put(CURRENTDATE, res.getString(res.getColumnIndex(CURRENTDATE)));
            hashmap.put(STATE,res.getString(res.getColumnIndex(STATE)));

            array_list.add(hashmap);
            res.moveToNext();
        }
        return array_list;
    }
}
