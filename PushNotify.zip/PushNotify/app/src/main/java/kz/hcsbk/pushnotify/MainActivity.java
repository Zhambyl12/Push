package kz.hcsbk.pushnotify;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private PushMessageDBHelper dbHelper;
    private static String LOG ="MainActivity";
    private ListView lv;
    private UpdateReceiver upd_res;
    private FoneService fservice;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(LOG, "=> onCreate");
        dbHelper = new PushMessageDBHelper(getApplicationContext());
        fservice = new FoneService();
        lv = (ListView) findViewById(R.id.card_listView);

        Log.i(LOG, "=> onStart");
        this.startService(new Intent(this, FoneService.class));

        upd_res = new UpdateReceiver();
        registerReceiver(upd_res, new IntentFilter("kz.hcsbk.action.UPDATE_ListView"));

        create_lv();
    }

    public void create_lv()
    {
        final ArrayList<HashMap<String, String>> notifications = dbHelper.GetAllMessages();

        SimpleAdapter adapter = new SimpleAdapter(this, notifications, R.layout.list, new String[]{"Title", "Content", "CurrentDate"}, new int[]{R.id.title, R.id.content, R.id.currentDate}) {
            @Override
            public View getView(final int position, View convertView, ViewGroup parent) {

                View view = super.getView(position, convertView, parent);
                Button btn = (Button) view.findViewById(R.id.acceptBtn);

                if(notifications.get(position).get("State").equals("0"))
                {
                    btn.setVisibility(View.VISIBLE);
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String post = notifications.get(position).get("Id");
                            dbHelper.UpdateMessage(post);
                            fservice.new AcceptFromAgent().execute(post);
                            create_lv();
                            Toast.makeText(getApplicationContext(),"Вы приняли уведомление!",Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                    btn.setVisibility(View.GONE);

                return view;
            }
        };
        lv.setEmptyView(findViewById(R.id.empTxt));
        lv.setAdapter(adapter);
    }

    public class UpdateReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            create_lv();
        }
    }
}
